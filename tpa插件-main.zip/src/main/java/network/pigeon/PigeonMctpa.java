
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.UUID;

public class PigeonMctpa extends JavaPlugin {
    private HashMap<UUID, Long> teleportRequests = new HashMap<>();

    @Override
    public void onEnable() {
        // 注册命令
        getCommand("tpb").setExecutor(new TeleportCommandExecutor(this));
    }

    public void requestTeleport(Player from, Player to) {
        long currentTime = System.currentTimeMillis();
        teleportRequests.put(to.getUniqueId(), currentTime);

        String messageToA = String.format("§e玩家%s还有60秒接受返回给%s:§e 来自玩家%s的传送请求，请输入/tpby接受或/tpbn拒绝", to.getName(), from.getName(), from.getName());
        from.sendMessage(messageToA);

        String messageToB = String.format("§e来自玩家%s的传送请求，请输入/tpby接受", from.getName());
        to.sendMessage(messageToB);

        // 启动一个延迟任务，60秒后检查是否接受了传送请求
        Bukkit.getScheduler().scheduleSyncDelayedTask(this, () -> {
            if (teleportRequests.containsKey(to.getUniqueId())) {
                long requestTime = teleportRequests.get(to.getUniqueId());
                long timeElapsed = System.currentTimeMillis() - requestTime;
                if (timeElapsed >= 60 * 1000) { // 60秒
                    from.sendMessage("§c传送请求已超时。");
                    teleportRequests.remove(to.getUniqueId());
                }
            }
        }, 20 * 60); // 20 ticks per second, 60 seconds
    }

    private static class TeleportCommandExecutor implements CommandExecutor {
        private PigeonMctpa plugin;

        public TeleportCommandExecutor(PigeonMctpa plugin) {
            this.plugin = plugin;
        }

        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("此命令只能由玩家执行。");
                return true;
            }

            Player player = (Player)sender;
            if (args.length == 0) {
                player.sendMessage("用法: /tpb <玩家名>");
                return true;
            }

            Player target = plugin.getServer().getPlayer(args[0]);
            if (target == null) {
                player.sendMessage("玩家未找到。");
                return true;
            }

            plugin.requestTeleport(player, target);
            return true;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("tpby")) {
            if (sender instanceof Player) {
                Player player = (Player)sender;
                if (teleportRequests.containsKey(player.getUniqueId())) {
                    teleportRequests.remove(player.getUniqueId());
                    // 确保存在来自玩家
                    Player from = Bukkit.getServer().getPlayer(player.getUniqueId());
                    if (from != null) {
                        from.teleport(player);
                        from.sendMessage("§e你已被传送到玩家" + player.getName());
                        player.sendMessage("§e玩家" + from.getName() + "已传送到你这里");
                    } else {
                        player.sendMessage("§c无法找到请求传送的玩家。");
                    }
                } else {
                    player.sendMessage("§c没有有效的传送请求。");
                }
                return true;
            }
        }
        // 这里添加了缺失的闭合大括号
        return false;
    }
}
